Observe App for Splunk allows you to query data from your Observeinc. tenant.
